# A Little World Called Us 💗

A multi-page, animated friendship website for Aditi and Shreya.

## Run locally
1. Extract the ZIP.
2. Open `index.html` in a browser, or use VS Code Live Server.
3. Navigate using the buttons. Each section is a separate HTML page.

## Customize before sharing
- Edit the letters in `aditi.html` and `shreya.html`.
- Add your real photos and memories to `story.html` or create extra memory cards.
- Optional background music: create an `assets` folder and add a royalty-free MP3 named `soft-piano.mp3`. Music starts only after the user taps the music button.
- Change colours and fonts in `style.css`.

## Deploy
Upload the extracted folder to Netlify, or connect its GitHub repository. No build command is needed; publish directory is the project root.

This is a static website: no login, tracking, or data collection. The site is a thoughtful gesture, not a substitute for listening and apologizing directly.

## Personalised dark-pink update
- Visitors enter their name first: Aditi or Shreya.
- Aditi sees a personalised greeting and her uploaded song in Aditi's room.
- Shreya sees a personalised greeting and her uploaded song in Shreya's room.
- Both rooms link to the shared Google Photos album.
- The songs are included in `assets/`. Playback begins only when the visitor presses play.
- This is a lightweight name gate, not secure authentication. Anyone who knows either name can enter.

## New additions
- Emoji-rich messages and enhanced apology heart interaction (pulse for one sincere sorry; grow dramatically for 1000).
- Reworked Fun Zone with playful, affectionate friendship surprises.
- Swami Samarth blessing room (`swami.html`) using the supplied image, animated temple doors, sunshine glow and a locally synthesised temple-bell chime when the doors open.
- The blessing room is linked from Fun Zone and Garden.

## Navigation fix
- Removed the name-entry/login screen completely.
- The site now opens directly on the welcome home page; tap **Come inside** to navigate to Our Story.
- Aditi and Shreya's individual rooms remain accessible from the Two Special People page.

Restored update: direct home page (no login), both songs, photo album links, personal NSS/photography story for Aditi, campus/Fashion Committee story for Shreya, portrait certificates, repaired button JavaScript, and Swami Samarth blessing doors retained.
